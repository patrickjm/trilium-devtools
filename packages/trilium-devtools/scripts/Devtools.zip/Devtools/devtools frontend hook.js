setInterval(() => {
    fetch('http://localhost:3001/dev/status', {
        method: 'POST'
    }).then(response => response.json())
    .then(result => {
      if (result.refresh) {
        window.location.reload()
      }
    })
}, 3000);