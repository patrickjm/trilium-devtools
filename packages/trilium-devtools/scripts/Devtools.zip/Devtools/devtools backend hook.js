const express = require('express')
const bodyParser = require('body-parser');
const app = express()
app.use(bodyParser.text())
const port = 3001

let status = {
    refresh: false
};

app.post('/dev/update', (req, res) => {
  const note = api.getNoteWithLabel('devtools');
  console.log('Devtools hot reload');
  note.setContent(req.body);
  status.refresh = true;
  res.sendStatus(200);
});

app.post('/dev/status', (req, res) => {
    res.header('Access-Control-Allow-Origin', '*')
        .json(status);
    status.refresh = false;
});

app.listen(port, () => {
  console.log(`Devtools listening at http://localhost:${port}`)
})